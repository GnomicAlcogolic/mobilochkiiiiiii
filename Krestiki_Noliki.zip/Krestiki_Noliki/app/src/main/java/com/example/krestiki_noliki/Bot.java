package com.example.krestiki_noliki;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.Objects;

public class Bot extends AppCompatActivity {
    private MaterialButton[][] buttons = new MaterialButton[3][3];
    private MaterialButton NewGame;
    private char[][] board = new char[3][3];
    TextView winsView, tiesView, losesView, statist;
    int playerXWins, playerOWins, ties;
    private char currentPlayer = 'X'; // Игрок X начинает игру
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bot);
        StatisticsGame game = LoadStatisticToShared();
        winsView = findViewById(R.id.wins);
        tiesView = findViewById(R.id.tires);
        losesView = findViewById(R.id.losses);
        NewGame = findViewById(R.id.newgame);
        statist = findViewById(R.id.statik);
        winsView.setText("Побед игрока: " + game.getWinsX());
        tiesView.setText("Ничьих: " + game.getTies());
        losesView.setText("Побед бота: " + game.getWinsO());
        buttons[0][0] = findViewById(R.id.button_00);
        buttons[0][1] = findViewById(R.id.button_01);
        buttons[0][2] = findViewById(R.id.button_02);
        buttons[1][0] = findViewById(R.id.button_03);
        buttons[1][1] = findViewById(R.id.button_04);
        buttons[1][2] = findViewById(R.id.button_05);
        buttons[2][0] = findViewById(R.id.button_06);
        buttons[2][1] = findViewById(R.id.button_07);
        buttons[2][2] = findViewById(R.id.button_08);
        NewGame = findViewById(R.id.newgame);

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                final int finalRow = row;
                final int finalCol = col;
                buttons[row][col].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onCellClick(buttons[finalRow][finalCol], finalRow, finalCol);
                    }
                });
            }
        }
        NewGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        buttons[i][j].setEnabled(true);
                        buttons[i][j].setText("");
                    }
                }
                statist.setText("");
            }
        });
    }
    private void onCellClick(MaterialButton button, int row, int col) {
        if (buttons[row][col].getText().equals("")) {
            buttons[row][col].setText("X");
            button.setText(String.valueOf(currentPlayer));

            char winner = checkForWin('X') ? 'X' : (checkForWin('O') ? 'O' : 0);

            if (winner != 0) {
                endGame(winner);
            } else if (isBoardFull()) {
                endGame('T'); // 'T' - для ничьей
            } else {
                currentPlayer = 'O';
                makeBotMove();
            }
        }
    }
    private void endGame(char winner) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setEnabled(false);
            }
        }

        if (winner == 'T') {
            ties++;
            Toast.makeText(this, "Ничья", Toast.LENGTH_SHORT).show();
        } else if(winner == 'X') {
            playerXWins++;
            Toast.makeText(this, "Игра завершена. Победитель: " + winner, Toast.LENGTH_SHORT).show();
        }else{
            playerOWins++;
            Toast.makeText(this, "Игра завершена. Победитель: " + winner, Toast.LENGTH_SHORT).show();
        }
        StatisticsGame statisticsGame = new StatisticsGame();
        statisticsGame.setWinsX(playerXWins);
        statisticsGame.setWinsO(playerOWins);
        statisticsGame.setTies(ties);
        SaveStatisticToShared(statisticsGame);
        winsView.setText("Побед игрока X: " + playerXWins);
        tiesView.setText("Ничьих: " + ties);
        losesView.setText("Побед бота: " + playerOWins);
    }
    private boolean checkForWin(char player) {
        // Проверка горизонтальных линий
        for (int row = 0; row < 3; row++) {
            if (buttons[row][0].getText().equals(String.valueOf(player)) &&
                    buttons[row][1].getText().equals(String.valueOf(player)) &&
                    buttons[row][2].getText().equals(String.valueOf(player))) {
                return true;
            }
        }

        // Проверка вертикальных линий
        for (int col = 0; col < 3; col++) {
            if (buttons[0][col].getText().equals(String.valueOf(player)) &&
                    buttons[1][col].getText().equals(String.valueOf(player)) &&
                    buttons[2][col].getText().equals(String.valueOf(player))) {
                return true;
            }
        }

        // Проверка диагоналей
        if (buttons[0][0].getText().equals(String.valueOf(player)) &&
                buttons[1][1].getText().equals(String.valueOf(player)) &&
                buttons[2][2].getText().equals(String.valueOf(player))) {
            return true;
        }
        return buttons[0][2].getText().equals(String.valueOf(player)) &&
                buttons[1][1].getText().equals(String.valueOf(player)) &&
                buttons[2][0].getText().equals(String.valueOf(player));// Если нет выигрышной комбинации
    }

    private void makeBotMove() {
        int[] botMove = findBestMove(board);

        if (botMove[0] >= 0 && botMove[1] >= 0) {
            int row = botMove[0];
            int col = botMove[1];

            buttons[row][col].setText("O");

            char winner = checkForWin('O') ? 'O' : 0;

            if (winner != 0) {
                endGame(winner);
            } else if (isBoardFull()) {
                endGame('T'); // 'T' - для ничьей
            } else {
                currentPlayer = 'X';
            }
        } else {
            Toast.makeText(this, "Игра завершилась с ошибкой: бот не смог найти ход.", Toast.LENGTH_SHORT).show();
        }
    }
    public int[] findBestMove(char[][] board) {
        int[] bestMove = new int[]{-1, -1};
        int bestScore = Integer.MIN_VALUE;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j].getText().equals("")) {
                    board[i][j] = 'O'; // Сделать временный ход бота (O)
                    int score = minimax(board, 0, false); // Вызвать минимакс для поиска оптимального хода
                    board[i][j] = ' '; // Отменить временный ход

                    if (score > bestScore) {
                        bestScore = score;
                        bestMove[0] = i;
                        bestMove[1] = j;
                    }
                }
            }
        }

        return bestMove;
    }
    private int minimax(char[][] board, int depth, boolean isMaximizing) {
        int result = evaluate(board);

        if (result != 0) {
            return result;
        }

        if (isMaximizing) {
            int bestScore = Integer.MIN_VALUE;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (board[i][j] == ' ') {
                        board[i][j] = 'O';
                        int score = minimax(board, depth + 1, false);
                        board[i][j] = ' ';
                        bestScore = Math.max(score, bestScore);
                    }
                }
            }
            return bestScore;
        } else {
            int bestScore = Integer.MAX_VALUE;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (buttons[i][j].getText().equals(" ")) {
                        board[i][j] = 'X';
                        int score = minimax(board, depth + 1, true);
                        board[i][j] = ' ';
                        bestScore = Math.min(score, bestScore);
                    }
                }
            }
            return bestScore;
        }
    }
    private int evaluate(char[][] board) {
        if (checkForWin('O')) {
            return 1; // Бот (O) выигрывает
        } else if (checkForWin('X')) {
            return -1; // Игрок (X) выигрывает
        } else if (isBoardFull()) {
            return 0; // Ничья
        }

        // Если нет выигрыша и доска не заполнена, вернуть оценку 0
        return 0;
    }
    private boolean isBoardFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j].getText().toString().isEmpty()) {
                    return false;
                }
            }
        }
        return true;
    }
    private void SaveStatisticToShared(StatisticsGame statistic) {
        SharedPreferences sharedPreferences = getSharedPreferences("GameStatistics", MODE_PRIVATE);
        SharedPreferences.Editor editor1 = sharedPreferences.edit();
        editor1.putInt("winsX", statistic.getWinsX());
        editor1.putInt("ties", statistic.getTies());
        editor1.putInt("winsO", statistic.getWinsO());
        editor1.apply();
    }

    private StatisticsGame LoadStatisticToShared() {
        SharedPreferences sharedPreferences = getSharedPreferences("GameStatistics", MODE_PRIVATE);
        int winsX = sharedPreferences.getInt("winsX", 0);
        int ties = sharedPreferences.getInt("ties", 0);
        int winsO = sharedPreferences.getInt("winsO", 0);
        StatisticsGame game = new StatisticsGame();
        game.setWinsX(winsX);
        game.setTies(ties);
        game.setWinsO(winsO);
        return game;
    }
}