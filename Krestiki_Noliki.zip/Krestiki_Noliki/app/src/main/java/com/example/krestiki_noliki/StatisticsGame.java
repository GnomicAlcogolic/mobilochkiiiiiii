package com.example.krestiki_noliki;

public class StatisticsGame {
    private int winsX;
    private int winsO;
    private int ties;
    public char[][] board;
    public char currentPlayer;
    public StatisticsGame(){
        winsX = 0;
        winsO = 0;
        ties = 0;
    }

    public int getWinsO() {
        return winsO;
    }
    public void setWinsO(int winsO) {
        this.winsO = winsO;
    }

    public int getWinsX() {
        return winsX;
    }
    public void setWinsX(int winsX) {
        this.winsX = winsX;
    }

    public int getTies() {
        return ties;
    }
    public void setTies(int ties) {
        this.ties = ties;
    }
}
