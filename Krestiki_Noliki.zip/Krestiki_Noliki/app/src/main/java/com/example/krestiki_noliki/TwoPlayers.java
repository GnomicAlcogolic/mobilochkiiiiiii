package com.example.krestiki_noliki;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.SwitchCompat;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.Objects;

public class TwoPlayers extends AppCompatActivity {
    private MaterialButton[][] buttons = new MaterialButton[3][3];
    private MaterialButton NewGame;
    private boolean GameOver = false;
    private String currentPlayer = "X";
    int playerXWins, playerOWins, tires;
    SharedPreferences settings;
    SharedPreferences.Editor editor;
    SwitchCompat switchButton;
    TextView winsView, tiesView, losesView, statist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two_players);
        StatisticsGame game = LoadStatisticToShared();
        winsView = findViewById(R.id.wins);
        tiesView = findViewById(R.id.tires);
        losesView = findViewById(R.id.losses);
        NewGame = findViewById(R.id.newgame);
        winsView.setText("Побед игрока X: " + game.getWinsX());
        tiesView.setText("Ничьих: " + game.getTies());
        losesView.setText("Побед игрока O: " + game.getWinsO());
        buttons[0][0] = findViewById(R.id.button_00);
        buttons[0][1] = findViewById(R.id.button_01);
        buttons[0][2] = findViewById(R.id.button_02);
        buttons[1][0] = findViewById(R.id.button_03);
        buttons[1][1] = findViewById(R.id.button_04);
        buttons[1][2] = findViewById(R.id.button_05);
        buttons[2][0] = findViewById(R.id.button_06);
        buttons[2][1] = findViewById(R.id.button_07);
        buttons[2][2] = findViewById(R.id.button_08);
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onCellClick((MaterialButton) v);
                    }
                });
            }
        }
    }

    private void onCellClick(MaterialButton button) {
        statist = findViewById(R.id.statik);
        if (button.getText().toString().isEmpty()) {
            button.setText(String.valueOf(currentPlayer));
            if (HorizontalWin(currentPlayer) || VerticalWin(currentPlayer) || DiagonalWin(currentPlayer)) {
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 3; j++) {
                        buttons[i][j].setEnabled(false);
                    }
                }
                if (Objects.equals(currentPlayer, "X")) {
                    playerXWins++;
                } else {
                    playerOWins++;
                }
                Toast.makeText(this, "Игра завершена", Toast.LENGTH_SHORT).show();
                statist.setText("Победил " + currentPlayer);


            } else {
                if (Objects.equals(currentPlayer, "X")) {
                    button.setText("X");
                    currentPlayer = "O";
                } else {
                    button.setText("O");
                    currentPlayer = "X";
                }
            }
            if (isBoardFull()) {
                tires++;
                Toast.makeText(this, "Ничья", Toast.LENGTH_SHORT).show();
            }
            winsView.setText("Побед игрока X: " + playerXWins);
            tiesView.setText("Ничьих: " + tires);
            losesView.setText("Побед игрока O: " + playerOWins);
            StatisticsGame statisticsGame = new StatisticsGame();
            statisticsGame.setWinsX(playerXWins);
            statisticsGame.setWinsO(playerOWins);
            statisticsGame.setTies(tires);
            SaveStatisticToShared(statisticsGame);
            NewGame.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int i = 0; i < 3; i++) {
                        for (int j = 0; j < 3; j++) {
                            buttons[i][j].setEnabled(true);
                            buttons[i][j].setText("");
                        }
                    }

                }
            });
        }
    }

    private boolean isBoardFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j].getText().toString().isEmpty()) {
                    return false;
                }
            }
        }
        return true;
    }
    private boolean HorizontalWin(String player) {
        for (int row = 0; row < 3; row++) {
            if (buttons[row][0].getText().equals(String.valueOf(player)) &&
                    buttons[row][1].getText().equals(String.valueOf(player)) &&
                    buttons[row][2].getText().equals(String.valueOf(player))) {
                return true;
            }
        }
        return false;
    }

    private boolean VerticalWin(String symbol) {
        for (int col = 0; col < 3; col++) {
            if (buttons[0][col].getText().equals(symbol) &&
                    buttons[1][col].getText().equals(symbol) &&
                    buttons[2][col].getText().equals(symbol)) {
                return true;
            }
        }
        return false;
    }

    private boolean DiagonalWin(String symbol) {
        if (buttons[0][0].getText().equals(symbol) &&
                buttons[1][1].getText().equals(symbol) &&
                buttons[2][2].getText().equals(symbol)) {
            return true;
        }
        return buttons[0][2].getText().equals(symbol) &&
                buttons[1][1].getText().equals(symbol) &&
                buttons[2][0].getText().equals(symbol);
    }

    private void SaveStatisticToShared(StatisticsGame statistic) {
        SharedPreferences sharedPreferences = getSharedPreferences("GameStatistics", MODE_PRIVATE);
        SharedPreferences.Editor editor1 = sharedPreferences.edit();
        editor1.putInt("winsX", statistic.getWinsX());
        editor1.putInt("ties", statistic.getTies());
        editor1.putInt("winsO", statistic.getWinsO());
        editor1.apply();
    }

    private StatisticsGame LoadStatisticToShared() {
        SharedPreferences sharedPreferences = getSharedPreferences("GameStatistics", MODE_PRIVATE);
        int winsX = sharedPreferences.getInt("winsX", 0);
        int ties = sharedPreferences.getInt("ties", 0);
        int winsO = sharedPreferences.getInt("winsO", 0);
        StatisticsGame game = new StatisticsGame();
        game.setWinsX(winsX);
        game.setTies(ties);
        game.setWinsO(winsO);
        return game;
    }

}